Gui: Press play to check out the camera path, after it is done. you can move around with the translation buttons on the gui.
The camera path is created with the animation.
fps is displayed in console, couldn't find a way to display it on the screen.

All the Functionality is present, plus projective texture mapping.

