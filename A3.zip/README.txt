Play -> plays the scene, press it twice to see full scene, saves path to camera_path.txt
The images for the movie are generated with no problem, but I could not figure out how to make it into a movie, they are generated when you press play.
Load image -> load tiff image
Load camera -> load ppc from file
Load Geometry -> load bin file
Save file -> save tiff image
Save camera -> save ppc

U,D,L,R,F,B -> translation up, down, etc
Tilt, pan, roll -> rotations
Z in, Z out -> zoom

brightness, constrast -> don't work
move step -> adjust minimum step of translation or rotation
