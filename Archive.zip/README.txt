To compile: I used a macbook pro with OSX 10.9, it builds with the makefile included if libtiff 4.03 and fltk 1.3.2 are installed.

My name is drawn is you click the DBUG button, and you can load any tiff file and run edge detection on it. Line segment and circle rasterization are implemented, and a fill circle function is provided in framebuffer if you want to draw a filled circle and not just the border.

Could not get saving TIFF images to save or brightness. Tried writing through tiles, strips and by the scan method and always got black or distorted images. It took most of my time, which is the reason I could not implement brightness properly.

